package com.example.sreejith.androidtest;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sreejithpattery on 23/04/16.
 */
public class JSONParser
{
    public static List<FixtureObject> parseFeed(String content)
    {
        List<FixtureObject> items = null;
        try
        {
            items = new ArrayList<>();
            JSONObject rootObject = new JSONObject(content);
            JSONArray ar= rootObject.getJSONArray("fixtures");
            FixtureObject fixtureObject = null;

            for(int i=0;i<ar.length();i++)
            {
                JSONObject fixJsObj = ar.getJSONObject(i);
                fixtureObject = new FixtureObject();
                fixtureObject.setMatchDate(fixJsObj.getString("date").trim());
                fixtureObject.setStatus(fixJsObj.getString("status").trim());
                fixtureObject.setMatchday(fixJsObj.getInt("matchday"));
                fixtureObject.setHomeTeamName(fixJsObj.getString("homeTeamName").trim());
                fixtureObject.setAwayTeamName(fixJsObj.getString("awayTeamName").trim());
                JSONObject fixJsScrObj = fixJsObj.getJSONObject("result");
                fixtureObject.setHomeTeamScore(fixJsScrObj.getInt("goalsAwayTeam"));
                fixtureObject.setAwayTeamScore(fixJsScrObj.getInt("goalsHomeTeam"));
                items.add(fixtureObject);
            }

            return items;
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            return null;
        }

    }

}
