package com.example.sreejith.androidtest;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by sreejithpattery on 23/04/16.
 */
public class FixtureDataSource extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "fixtures.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_FIXTURE = "fixtures";

    public static final String MATCH_DATE = "matchdate";
    public static final String FIXTURE_ID = "_id";
    public static final String STATUS = "status";
    public static final String MATCH_DAY = "matchday";
    public static final String HOME_TEAM_NAME = "homeTeamName";
    public static final String AWAY_TEAM_NAME = "awayTeamName";
    public static final String HOME_TEAM_SCORE = "HomeTeamScore";
    public static final String AWAY_TEAM_SCORE = "AwayTeamScore";

    private static final String TABLE_CREATE = "CREATE TABLE "+TABLE_FIXTURE
            +" ("+FIXTURE_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+HOME_TEAM_NAME+" TEXT,"
            +AWAY_TEAM_NAME+" TEXT,"
            +STATUS+" TEXT,"
            +HOME_TEAM_SCORE+" INTEGER,"
            +AWAY_TEAM_SCORE+" INTEGER,"
            +MATCH_DATE+" TEXT,"
            +MATCH_DAY+" INTEGER)";

    public static  final String[] ALL_COLUMNS = {
            FIXTURE_ID,
            HOME_TEAM_NAME,
            AWAY_TEAM_NAME,
            STATUS,
            HOME_TEAM_SCORE,
            AWAY_TEAM_SCORE,
            MATCH_DATE,
            MATCH_DAY
    };


    public FixtureDataSource(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS "+ TABLE_FIXTURE);
        onCreate(db);
    }
}
