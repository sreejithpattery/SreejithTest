package com.example.sreejith.androidtest;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by sreejithpattery on 23/04/16.
 */
public class FixtureObject
{
    public FixtureObject()
    {
    }

    private String matchDate;
    private String status;
    private int matchday;
    private String homeTeamName;
    private String awayTeamName;
    private int HomeTeamScore;
    private int AwayTeamScore;

    public String getMatchDate()
    {
        DateFormat dtFormat = new SimpleDateFormat("yyyy-MM-dd");
        String strMatchDate = null;


        try
        {
            Date dt = dtFormat.parse(matchDate);
            dtFormat = new SimpleDateFormat("dd-MM-yyyy");
            strMatchDate = dtFormat.format(dt);
        }
        catch (ParseException e)
        {
            e.printStackTrace();
        }
        return strMatchDate;
    }

    public void setMatchDate(String matchDate) {
        this.matchDate = matchDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getMatchday() {
        return matchday;
    }

    public void setMatchday(int matchday) {
        this.matchday = matchday;
    }

    public String getHomeTeamName() {
        return homeTeamName;
    }

    public void setHomeTeamName(String homeTeamName) {
        this.homeTeamName = homeTeamName;
    }

    public String getAwayTeamName() {
        return awayTeamName;
    }

    public void setAwayTeamName(String awayTeamName) {
        this.awayTeamName = awayTeamName;
    }

    public int getHomeTeamScore() {
        return HomeTeamScore;
    }

    public void setHomeTeamScore(int homeTeamScore) {
        HomeTeamScore = homeTeamScore;
    }

    public int getAwayTeamScore() {
        return AwayTeamScore;
    }

    public void setAwayTeamScore(int awayTeamScore) {
        AwayTeamScore = awayTeamScore;
    }

    @Override
    public String toString() {
        return "Home Team:"+homeTeamName+"\n"
                +"Away Team:"+awayTeamName+"\n"
                +"Status:"+status+"\n"
                +"Goals: Home Team:"+getHomeTeamScore()+" Away Team:"+getAwayTeamScore()+"\n"
                +"Date:"+getMatchDate()
                ;
    }
}
