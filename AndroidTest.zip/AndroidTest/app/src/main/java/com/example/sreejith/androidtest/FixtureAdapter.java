package com.example.sreejith.androidtest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by sreejithpattery on 23/04/16.
 */
public class FixtureAdapter extends ArrayAdapter<FixtureObject>
{
    private Context context;
    private List<FixtureObject> objects;

    public FixtureAdapter(Context context, int resource,List<FixtureObject> objects)
    {
        super(context, resource,objects);

        this.context = context;
        this.objects = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);

        if(convertView == null)
        {
            View view = inflater.inflate(R.layout.item_fixture, parent, false);
            FixtureObject fixtureObject = objects.get(position);

            TextView txtHomeTeamName = (TextView) view.findViewById(R.id.txtHomeTeamName);
            txtHomeTeamName.setText(fixtureObject.getHomeTeamName());
            TextView txtAwayTeamName = (TextView) view.findViewById(R.id.txtAwayTeamName);
            txtAwayTeamName.setText(fixtureObject.getAwayTeamName());
            TextView txtStatusValue = (TextView) view.findViewById(R.id.txtStatusValue);
            txtStatusValue.setText(fixtureObject.getStatus());
            TextView txtGoalsValue = (TextView) view.findViewById(R.id.txtGoalsValue);
            txtGoalsValue.setText(
                    +fixtureObject.getHomeTeamScore()+" - "
                    +fixtureObject.getAwayTeamScore());
            TextView txtMatchDateValue = (TextView) view.findViewById(R.id.txtMatchDateValue);
            txtMatchDateValue.setText(fixtureObject.getMatchDate());

            return view;
        }
        else
        {
            return convertView;
        }
    }
}
