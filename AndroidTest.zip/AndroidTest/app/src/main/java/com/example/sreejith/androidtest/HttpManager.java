package com.example.sreejith.androidtest;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by sreejithpattery on 23/04/16.
 */
public class HttpManager
{
    public static String getData(String uri)
    {
        BufferedReader bufferedReader = null;
        try
        {
            URL url = new URL(uri);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();

            StringBuilder sb = new StringBuilder();
            bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line = "";

            while ((line =bufferedReader.readLine())!=null)
            {
                sb.append(line+"\n");
            }

            return sb.toString();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
            return null;
        }
        finally
        {
            if(bufferedReader!=null)
            {
                try
                {
                    bufferedReader.close();
                }
                catch (Exception ex)
                {
                    ex.printStackTrace();
                    return null;
                }
            }
        }
    }
}
