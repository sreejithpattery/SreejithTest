package com.example.sreejith.androidtest;

import android.app.ListActivity;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainActivity extends ListActivity
{
    public static final String DATA_URL = "http://api.football-data.org/alpha/soccerseasons/398/fixtures";
    public List<FixtureObject> listItems;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listItems = new ArrayList<>();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
        {
            MyTask myTask = new MyTask();
            myTask.execute(DATA_URL);
            return true;
        }

        return false;
    }



    public class MyTask extends AsyncTask<String,Void,Void>
    {

        @Override
        protected Void doInBackground(String... params)
        {

            Cursor cursor = getContentResolver().query(FixtureDataProvider.CONTENT_URI, FixtureDataSource.ALL_COLUMNS, null, null, null, null);
            FixtureObject fixtureObject;

            if(cursor.getCount()==0)
            {
                String conent = HttpManager.getData(params[0]);
                listItems = JSONParser.parseFeed(conent);

                ContentValues contentValues = null;
                Iterator<FixtureObject> listIterator= listItems.iterator();

                while (listIterator.hasNext())
                {
                    fixtureObject = listIterator.next();
                    contentValues = new ContentValues();
                    contentValues.put(FixtureDataSource.HOME_TEAM_NAME,fixtureObject.getHomeTeamName());
                    contentValues.put(FixtureDataSource.AWAY_TEAM_NAME,fixtureObject.getAwayTeamName());
                    contentValues.put(FixtureDataSource.STATUS,fixtureObject.getStatus());
                    contentValues.put(FixtureDataSource.HOME_TEAM_SCORE,fixtureObject.getHomeTeamScore());
                    contentValues.put(FixtureDataSource.AWAY_TEAM_SCORE,fixtureObject.getAwayTeamScore());
                    contentValues.put(FixtureDataSource.MATCH_DATE,fixtureObject.getMatchDate());
                    contentValues.put(FixtureDataSource.MATCH_DAY,fixtureObject.getMatchday());
                    getContentResolver().insert(FixtureDataProvider.CONTENT_URI, contentValues);
                }
            }
            else
            {
                listItems = new ArrayList<>();
                while (cursor.moveToNext())
                {
                    fixtureObject = new FixtureObject();
                    fixtureObject.setHomeTeamName(cursor.getString(cursor.getColumnIndex(FixtureDataSource.HOME_TEAM_NAME)));
                    fixtureObject.setAwayTeamName(cursor.getString(cursor.getColumnIndex(FixtureDataSource.AWAY_TEAM_NAME)));
                    fixtureObject.setStatus(cursor.getString(cursor.getColumnIndex(FixtureDataSource.STATUS)));
                    fixtureObject.setHomeTeamScore(cursor.getInt(cursor.getColumnIndex(FixtureDataSource.HOME_TEAM_SCORE)));
                    fixtureObject.setAwayTeamScore(cursor.getInt(cursor.getColumnIndex(FixtureDataSource.AWAY_TEAM_SCORE)));
                    fixtureObject.setMatchDate(cursor.getString(cursor.getColumnIndex(FixtureDataSource.MATCH_DATE)));
                    fixtureObject.setMatchday(cursor.getInt(cursor.getColumnIndex(FixtureDataSource.MATCH_DAY)));
                    listItems.add(fixtureObject);
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid)
        {
            updateDisplay();
        }
    }

    private void updateDisplay()
    {
        FixtureAdapter fixAdapter = new FixtureAdapter(this,R.layout.item_fixture,listItems);
        setListAdapter(fixAdapter);
    }

}
