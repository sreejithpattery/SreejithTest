package com.example.sreejith.androidtest;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

/**
 * Created by sreejithpattery on 23/04/16.
 */
public class FixtureDataProvider extends ContentProvider
{
    private static final String AUTHORITY = "com.example.sreejithpattery.androidtest.fixturedataprovider";
    private static final String BASE_PATH = "fixtures";
    public static final Uri CONTENT_URI = Uri.parse("content://"+AUTHORITY+"/"+BASE_PATH);

    private static UriMatcher uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    private static final int FIXTURE = 1;
    private static final int FIXTURE_ID = 2;

    private static final String CONTENT_TYPE = "Fixture";

    FixtureDataSource dbHelper;
    SQLiteDatabase database;

    static
    {
        uriMatcher.addURI(AUTHORITY,BASE_PATH,FIXTURE);
        uriMatcher.addURI(AUTHORITY,BASE_PATH+"/#",FIXTURE_ID);
    }

    @Override
    public boolean onCreate()
    {
        dbHelper = new FixtureDataSource(getContext());
        database = dbHelper.getWritableDatabase();
        return false;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)
    {
        if(uriMatcher.match(uri)==FIXTURE_ID)
        {
            selection = FixtureDataSource.FIXTURE_ID+"="+uri.getLastPathSegment();
        }


        return database.query(FixtureDataSource.TABLE_FIXTURE,FixtureDataSource.ALL_COLUMNS,selection,null,null,null,FixtureDataSource.FIXTURE_ID+" ASC");
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values)
    {
        long id = database.insert(FixtureDataSource.TABLE_FIXTURE,null,values);
        return uri.parse(BASE_PATH+"/"+id);
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs)
    {
        return database.delete(FixtureDataSource.TABLE_FIXTURE,selection,selectionArgs);
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return database.update(FixtureDataSource.TABLE_FIXTURE,values,selection,selectionArgs);
    }
}
